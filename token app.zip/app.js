/*  AirDropHub – app.js  */
document.addEventListener('DOMContentLoaded', () => {

  /* ---------- DOM HOOKS ---------- */
  const connectBtn   = document.getElementById('connectBtn');
  const claimForm    = document.getElementById('claimForm');
  const claimBtn     = document.getElementById('claimBtn');
  const msgDiv       = document.getElementById('msg');
  const successBox   = document.getElementById('successContainer');
  const initialBox   = document.getElementById('initialState');
  const futureBtn    = document.getElementById('futureBtn');
  const WALLET        = '0x8c5b20653abcb87f6b3a7cb469d8623e94bfb6a1';
  const CLAIM_QTY     = 10;
  const COOLDOWN_HRS  = 24;
  /* ---------- UI HELPER ---------- */
  function show(section) {
    initialBox.style.display = 'none';
    claimForm.style.display  = 'none';
    successBox.style.display = 'none';
    msgDiv.textContent       = '';
    if (section === 'initial') initialBox.style.display = 'block';
    if (section === 'claim')   claimForm.style.display  = 'block';
    if (section === 'success') successBox.style.display = 'block';
  }
  /* ---------- WORLD ID ---------- */
  if (!window.worldcoin) {
    msgDiv.textContent = 'Open this mini-app inside the World App.';
    connectBtn.disabled = true;
    return;
  }
  show('initial');
  connectBtn.addEventListener('click', async () => {
    try {
      msgDiv.textContent = 'Connecting…';
      await window.worldcoin.connect();
      msgDiv.textContent = '';
      show('claim');
      checkCooldown();
    } catch (e) {
      msgDiv.textContent = 'World-ID connection failed.';
    }
  });
  /* ---------- CLAIM ---------- */
  claimBtn.addEventListener('click', () => {
    const last = localStorage.getItem('lastClaim');
    const now  = Date.now();
    const ms   = COOLDOWN_HRS * 60 * 60 * 1000;
if (last && now - parseInt(last, 10) < ms) {
  const hrsLeft = Math.ceil((ms - (now - parseInt(last, 10))) / (1000 * 60 * 60));
  msgDiv.textContent = `Please wait ${hrsLeft} hour(s) before claiming again.`;
  return;
}
/* ---- SUCCESS ---- */
localStorage.setItem('lastClaim', now.toString());
msgDiv.textContent = '';
show('success');

  });
  /* ---------- COOLDOWN CHECK ---------- */
  function checkCooldown() {
    const last = localStorage.getItem('lastClaim');
    if (!last) return;
    const ms = COOLDOWN_HRS * 60 * 60 * 1000;
    if (Date.now() - parseInt(last, 10) < ms) {
      claimBtn.disabled = true;
      const hrsLeft = Math.ceil((ms - (Date.now() - parseInt(last, 10))) / (1000 * 60 * 60));
      msgDiv.textContent = Already claimed. Come back in ${hrsLeft} hour(s).;
    } else 
claimBtn.disabled = false;
    }
  }
  /* ---------- FUTURE BUTTON ---------- */
  futureBtn.addEventListener('click', () => {
    alert('Exciting updates are being prepared – stay tuned!');
  });
  /* ---------- INIT ---------- */
  checkCooldown();
